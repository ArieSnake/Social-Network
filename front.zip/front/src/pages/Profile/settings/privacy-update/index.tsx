import { useOutletContext } from 'react-router-dom';
import { MDBContainer, MDBRow, MDBCol, MDBCard, MDBCardBody } from 'mdb-react-ui-kit';
import { toast, ToastContainer } from 'react-toastify';
import { IContextType } from '../../../../lib/types';
import { handlePrivacyUpdate } from '../../../../lib/api';
import {DEFAULT_PRIVATE_PIC, DEFAULT_PUBLIC_PIC } from '../../../../lib/constant'; // Assuming these images are imported

export const PrivacyUpdate = () => {
    const { account, setAccount } = useOutletContext<IContextType>();  // Ensure this matches the context type
    const isPrivate = account.isPrivate;

    const togglePrivacy = () => {
        handlePrivacyUpdate(!isPrivate)
            .then(response => {
                if (response.status === 'ok') {
                    toast.success('Privacy status updated successfully!');
                    setAccount({ ...account, isPrivate: !isPrivate });
                } else {
                    toast.error(response.message || 'Failed to update privacy status.');
                }
            })
            .catch(() => {
                toast.error('Network error or server is down.');
            });
    };

    return (
        <MDBContainer className="py-5" style={{ maxWidth: '600px' }}>
            <ToastContainer />
            <MDBRow className="d-flex justify-content-center">
                <MDBCol md="12">
                    <MDBCard className="my-5">
                        <MDBCardBody className="p-5">
                            <h3 className="mb-4">Privacy Settings</h3>

                            <p>Your account is currently <strong>{isPrivate ? 'Private' : 'Public'}</strong>.</p>

                            <div className="text-center">
                                <img
                                    src={isPrivate ? DEFAULT_PRIVATE_PIC : DEFAULT_PUBLIC_PIC}
                                    alt={isPrivate ? 'Private' : 'Public'}
                                    style={{ cursor: 'pointer', width: '100px' }}
                                    onClick={togglePrivacy}
                                />
                                <p>Click the lock icon to toggle your privacy status.</p>
                            </div>

                        </MDBCardBody>
                    </MDBCard>
                </MDBCol>
            </MDBRow>
        </MDBContainer>
    );
};
